import { NgModule } from "@angular/core";
import { ListsComponent } from "./lists.component";
import { CommonModule } from "@angular/common";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { IonicModule } from "@ionic/angular";
import { ListsRoutingModule } from "./lists-routing.module";
import { AddItemComponent } from "./add-item/add-item.component";
import { SharedComponentsModule } from "../shared/shared-components.module";

@NgModule({
    imports: [
      CommonModule,
      FormsModule,
      IonicModule,
      ReactiveFormsModule,
      ListsRoutingModule,
      SharedComponentsModule
    ],
    declarations: [ListsComponent, AddItemComponent]
  })
  export class ListsModule {}