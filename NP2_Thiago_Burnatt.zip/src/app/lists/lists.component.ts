import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { NotificationService } from 'src/shared/services/notification.service';
import { StorageService } from 'src/shared/services/storage.service';
import { IList } from 'src/shared/interfaces/lists.interface';

@Component({
  selector: 'app-lists',
  templateUrl: './lists.component.html',
  styleUrls: ['./lists.component.scss'],
})
export class ListsComponent  implements OnInit {
  formData: FormGroup;
  lists: IList[] = [];

  constructor(
    private notificationService: NotificationService,
    private storageService: StorageService<IList>,
    private router: Router,
    ) {}

  ngOnInit() {
    this.createForm();
  }

  ionViewDidEnter() {
    this.loadLists();
  }

  createForm() {
    this.formData = new FormGroup({
      name: new FormControl('', [Validators.required]),
      budget: new FormControl('', [Validators.required])
    });
  }

  onSubmit(formData: FormGroup) {
    if (!formData.valid) {
      this.notificationService.showAlert('Por favor insira o nome da lista e valor');
      return;
    }

    const list: IList = {
      id: Date.now(),
      name: formData.value.name,
      budget: formData.value.budget,
      items: []
    }
    this.lists.push(list);
    this.storageService.save('lists', this.lists)

    this.router.navigate(['/listas/novo', list.id]);
  }

  loadLists() {
    this.storageService.getAll('lists').then(lists => {
      this.lists = lists ? lists : [];
    })
  }

}
