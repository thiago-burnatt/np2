import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ICategory } from 'src/shared/interfaces/categories.interface';
import { IItem } from 'src/shared/interfaces/items.interface';
import { IListItem } from 'src/shared/interfaces/list-item.interface';
import { IList } from 'src/shared/interfaces/lists.interface';
import { StorageService } from 'src/shared/services/storage.service';
import { NotificationService } from 'src/shared/services/notification.service';
import { ActivatedRoute, Params } from '@angular/router';
import { map } from 'rxjs';
import { IClickAction } from 'src/shared/interfaces/clickAction.interface';
import { LoadingService } from 'src/shared/services/loading.service';

@Component({
  selector: 'app-add-item',
  templateUrl: './add-item.component.html',
  styleUrls: ['./add-item.component.scss'],
})
export class AddItemComponent  implements OnInit {
  headerCols = ['Nome', 'Categoria', 'Valor', 'Qde', 'Excluir'];
  formData: FormGroup
  items: IItem[] = [];
  itemList: IListItem[] = [];
  categories: ICategory[] = [];
  lists: IList[] = [];
  selectedListIndex: number;
  selectedList: IList;
  isLoading = true;

  constructor(
    private storageServiceLists: StorageService<IList>,
    private storageServiceItems: StorageService<IItem>,
    private notificationService: NotificationService,
    private activatedRoute: ActivatedRoute,
    private loadingService: LoadingService
    ) { }

  ionViewDidEnter() {
    this.loadItems();
    this.loadSelectedList();
  }

  ngOnInit() {
    this.createForm();
  }

  createForm() {
    this.formData = new FormGroup({
      item: new FormControl('', [Validators.required]),
      quantity: new FormControl('', [Validators.required])
    });
  }

  onSubmit(formData: FormGroup) {
    if (!formData.valid) {
      this.notificationService.showAlert('Por favor insira um item');
      return;
    }   
    this.lists[this.selectedListIndex].items.push({
      ...formData.value,
      checked: false,
    })
    this.formData.reset();
    this.saveList();
  }

  saveList() {
    this.storageServiceLists.save('lists', this.lists);
  }

  delete(index: number) {
    this.lists[this.selectedListIndex].items.splice(index, 1);
    this.saveList();
  }

  loadSelectedList() {
    this.storageServiceLists.getAll('lists').then(lists => {
      this.lists = lists ? lists : [];
      this.activatedRoute.params.pipe(map(((params: Params) => {
        this.selectedList = this.findList(+params['id'], lists)!;
      }))).subscribe(() => {}
      )
    })
  }

  loadItems() {
    this.loadingService.showLoading();
    this.storageServiceItems.getAll('items').then(items => {
      this.items = items ? items : [];
      this.isLoading = false;
      this.loadingService.hideLoading();
    })
  }

  findList(id: number, lists: IList[]) {
    return lists.find((item, index) => {
      this.selectedListIndex = index;
      return item.id === id;
    });  
  }

  onclickAction(data: IClickAction) {
    this.delete(data.index);
  }

}
