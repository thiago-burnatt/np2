import { AfterContentChecked, Component, Input } from '@angular/core';
import { IList } from 'src/shared/interfaces/lists.interface';

@Component({
  selector: 'app-show-budget',
  templateUrl: './show-budget.component.html',
  styleUrls: ['./show-budget.component.scss'],
})
export class ShowBudgetComponent  implements AfterContentChecked {
  @Input() selectedList: IList;
  itemsSum: number = 0;

  constructor() { }
  ngAfterContentChecked(): void {
    this.sumAllItems();
  }

  sumAllItems() {
    this.itemsSum = 0;
    this.selectedList?.items?.forEach(item => {
      this.itemsSum += item.item.value * item.quantity;
    });
  }

}
