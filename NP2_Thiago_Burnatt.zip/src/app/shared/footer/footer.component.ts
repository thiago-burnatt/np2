import { Component, Input } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.scss'],
})
export class FooterComponent {
  @Input() showItemBtn = true;
  @Input() showCategoriesBtn = true;
  @Input() showListBtn = true;
  @Input() showMyListsBtn = true;

  constructor(private router: Router) { }

  onNavigate(path: string) {
    this.router.navigate([path])
  }

}
