import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { IonicModule } from "@ionic/angular";
import { FooterComponent } from "./footer/footer.component";
import { HeaderComponent } from "./header/header.component";
import { ShowBudgetComponent } from "./show-budget/show-budget.component";
import { TableComponent } from "./table/table.component";
import { NoDataComponent } from "./no-data/no-data.component";

@NgModule({
  imports: [CommonModule, IonicModule],
  exports: [FooterComponent, HeaderComponent, ShowBudgetComponent, TableComponent, NoDataComponent],
  declarations: [FooterComponent, HeaderComponent, ShowBudgetComponent, TableComponent, NoDataComponent]
})
export class SharedComponentsModule {}