import { Component, EventEmitter, Input, OnDestroy, OnInit, Output } from '@angular/core';
import { IClickAction } from 'src/shared/interfaces/clickAction.interface';
import { IItem } from 'src/shared/interfaces/items.interface';
import { IListItem } from 'src/shared/interfaces/list-item.interface';
import { IList } from 'src/shared/interfaces/lists.interface';

@Component({
  selector: 'app-table',
  templateUrl: './table.component.html',
  styleUrls: ['./table.component.scss'],
})
export class TableComponent {
  @Input() headerCols: string[];
  @Input() tableCols: IListItem[] | IItem[] | any[];
  @Input() iconName: string;
  @Input() context: string;
  @Output() clickAction = new EventEmitter<IClickAction>();

  onClickAction(index: number, action: string) {
    this.clickAction.emit({index, action} as IClickAction);
  }
}
