import { Component, Input } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss'],
})
export class HeaderComponent {
  @Input() _titleLabel: string;
  get titleLabel() {
   return this._titleLabel?.length >= 14 ? this._titleLabel.replace(this._titleLabel.substring(12, this._titleLabel?.length), '...') : this._titleLabel;
  }

  constructor(private router: Router) { }

  nagivateToHome() {
    this.router.navigate(['home'])
  }
}
