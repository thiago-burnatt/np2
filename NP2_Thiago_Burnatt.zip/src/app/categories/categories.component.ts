import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { StorageService } from '../../shared/services/storage.service';
import { ICategory } from 'src/shared/interfaces/categories.interface';
import { NotificationService } from 'src/shared/services/notification.service';
import { LoadingService } from 'src/shared/services/loading.service';

@Component({
  selector: 'app-categories',
  templateUrl: './categories.component.html',
  styleUrls: ['./categories.component.scss'],
})
export class CategoriesComponent  implements OnInit {
  formData: FormGroup;
  categoryList: any[] = [];
  lista: ICategory[] = [];
  isEdit = false;
  currentIndex: number;
  isLoading = true;

  constructor(
    private storageService: StorageService<ICategory>,
    private notificationService: NotificationService,
    private loadingService: LoadingService
    ) { }

  ionViewDidEnter() {
    this.loadCategories();
  }

  ngOnInit() {
    this.createForm();
  }

  loadCategories() {
    this.loadingService.showLoading();
    this.storageService.getAll('categories').then(categories => {
      this.categoryList = categories ? categories : [];
      this.isLoading = false;
      this.loadingService.hideLoading();
    })
  }

  createForm() {
    this.formData = new FormGroup({
      name: new FormControl('', [Validators.required])
    });
  }

  onSubmit(formData: FormGroup) {

    if (!formData.valid) {
      this.notificationService.showAlert('Por favor insira uma categoria');
      return;
    }
    if (this.isEdit) {
      this.categoryList[this.currentIndex].name = formData.value.name; 
    } else {
      const category: ICategory = {
        id: Date.now(),
        name: formData.value.name
      }
      
      this.categoryList.push(category);
    }
    this.storageService.save('categories', this.categoryList)
    this.isEdit = false;
    this.formData.reset();
  }

  edit(index: number) {
    this.formData.setValue({
      name: this.categoryList[index].name,
    });
    this.isEdit = true;
    this.currentIndex = index;
  }

  delete(index: number) {
    this.categoryList.splice(index, 1);
    this.storageService.save('categories', this.categoryList);
  }

  findById(id: number, list: ICategory[]) {
    return list.find((item, index) => {
      return item.id === id
    });
  }

}
