import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { IonicModule } from "@ionic/angular";
import { CategoriesRoutingModule } from "./categories-routing.module";
import { CategoriesComponent } from "./categories.component";
import { SharedComponentsModule } from "../shared/shared-components.module";

@NgModule({
    imports: [
      CommonModule,
      FormsModule,
      IonicModule,
      ReactiveFormsModule,
      CategoriesRoutingModule,
      SharedComponentsModule
    ],
    declarations: [CategoriesComponent]
  })
  export class CategoriesModule {}