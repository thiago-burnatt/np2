import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { IClickAction } from 'src/shared/interfaces/clickAction.interface';
import { IList } from 'src/shared/interfaces/lists.interface';
import { LoadingService } from 'src/shared/services/loading.service';
import { StorageService } from 'src/shared/services/storage.service';

@Component({
  selector: 'app-show-lists',
  templateUrl: './show-lists.component.html',
  styleUrls: ['./show-lists.component.scss'],
})
export class ShowListsComponent {
  headerCols = ['Nome', 'Categoria', 'Valor', 'Qde', 'Comprado'];
  lists: IList[] = [];
  selectedList: IList;
  selectedListIndex: number;
  isLoading = true;

  constructor(
    private storageService: StorageService<IList>,
    private router: Router,
    private loadingService: LoadingService
    ) { }


  ionViewDidEnter() {
    this.loadLists()
    this.selectedList = null as any;
  }

  loadLists() {
    this.loadingService.showLoading();
    this.storageService.getAll('lists').then(data => {
      this.lists = data ? data : [];
      this.isLoading = false;
      this.loadingService.hideLoading();
    })
  }

  onSelect(event: any) {
    this.selectedList = this.findById(event.detail.value.id) as IList;
  }

  onEdit(id: number) {
    this.router.navigate([`listas/novo/${id}`])
  }

  onDelete() {
    this.lists.splice(this.selectedListIndex, 1);
    this.storageService.save('lists', this.lists);
    this.router.navigate(['/']);
  }

  checked(index: number) {
    this.selectedList.items[index].checked = !this.selectedList.items[index].checked;
    this.replaceSelectedList();
    this.storageService.save('lists', this.lists, false)
  }

  replaceSelectedList() {
    this.lists[this.selectedListIndex] = this.selectedList;
  }

  findById(id: number) {
    return this.lists.find((item, index) => {
      this.selectedListIndex = index;
      return item.id === id;
    });
  }

  onclickAction(data: IClickAction) {
    this.checked(data.index);
  }

}
