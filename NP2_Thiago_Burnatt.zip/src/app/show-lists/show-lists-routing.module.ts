import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { ShowListsComponent } from "./show-lists.component";

const routes: Routes = [
    {
      path: '',
      component: ShowListsComponent,
    }
  ];
  
  @NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
  })
  export class ShowListsRoutingModule {}