import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { FormsModule } from "@angular/forms";
import { IonicModule } from "@ionic/angular";
import { ShowListsRoutingModule } from "./show-lists-routing.module";
import { ShowListsComponent } from "./show-lists.component";
import { SharedComponentsModule } from "../shared/shared-components.module";

@NgModule({
    imports: [
      CommonModule,
      FormsModule,
      IonicModule,
      ShowListsRoutingModule,
      SharedComponentsModule
    ],
    declarations: [ShowListsComponent]
  })
  export class ShowListsModule {}