import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { StorageService } from '../../shared/services/storage.service';
import { ICategory } from 'src/shared/interfaces/categories.interface';
import { IItem } from 'src/shared/interfaces/items.interface';
import { NotificationService } from 'src/shared/services/notification.service';
import { IClickAction } from 'src/shared/interfaces/clickAction.interface';
import { LoadingService } from 'src/shared/services/loading.service';

@Component({
  selector: 'app-items',
  templateUrl: './items.component.html',
  styleUrls: ['./items.component.scss'],
})
export class ItemsComponent  implements OnInit {
  headerCols = ['Nome', 'Categoria', 'Valor', 'Editar', 'Excluir'];
  formData: FormGroup;
  items: IItem[] = [];
  categories: ICategory[] = [];
  isEdit = false;
  currentIndex: number;
  isLoading = true;

  constructor(
    private storageService: StorageService<IItem>,
    private storageServiceCategories: StorageService<ICategory>,
    private notificationService: NotificationService,
    private loadingService: LoadingService
    ) { }
  
  ionViewDidEnter() {
    this.loadCategories();
    this.loadItems();  
  }

  ngOnInit() {
    this.createForm();
  }

  loadItems() {
    this.loadingService.showLoading();
    this.storageService.getAll('items').then(items => {
      this.items = items ? items : [];
      this.isLoading = false;
      this.loadingService.hideLoading();
    })
  }

  createForm() {
    this.formData = new FormGroup({
      name: new FormControl('', [Validators.required]),
      category: new FormControl('', [Validators.required]),
      value: new FormControl('', [Validators.required])
    });
  }

  onSubmit(formData: FormGroup) {
    if (!formData.valid) {
      this.notificationService.showAlert('Por favor insira um item');
      return;
    }
    if (this.isEdit) {
      this.items[this.currentIndex].name = formData.value.name; 
      this.items[this.currentIndex].category = formData.value.category; 
      this.items[this.currentIndex].value = formData.value.value;
    } else {
      const item: IItem = {
        id: this.idGenerator(),
        name: formData.value.name,
        category: formData.value.category,
        value: formData.value.value
      }
      this.items.push(item);
    }

    this.storageService.save('items', this.items);
    this.isEdit = false;
    this.formData.reset(); 
  }

  edit(index: number) {
    this.formData.setValue({
      name: this.items[index].name,
      category: this.items[index].category,
      value: this.items[index].value
    });
    this.isEdit = true;
    this.currentIndex = index;
  }

  delete(index: number) {
    this.items.splice(index, 1);
    this.storageService.save('items', this.items);
  }

  idGenerator(): number {
    return Date.now();
  }

  loadCategories() {
    this.storageServiceCategories.getAll('categories').then(categories => {
      this.categories = categories;
    })
  }

  onclickAction(data: IClickAction) {
    if (data.action === 'edit') {
      this.edit(data.index);
    }
    if (data.action === 'delete') {
      this.delete(data.index);
    }
  }

}
