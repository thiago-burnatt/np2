import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { IonicModule } from "@ionic/angular";
import { ItemsComponent } from "./items.component";
import { ItemsRoutingModule } from "./items-routing.module";
import { SharedComponentsModule } from "../shared/shared-components.module";

@NgModule({
  imports: [    
    CommonModule,
    FormsModule,
    IonicModule,
    ReactiveFormsModule,
    ItemsRoutingModule,
    SharedComponentsModule
  ],
  declarations: [ItemsComponent]
})
export class ItemsModule {}