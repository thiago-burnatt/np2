import { Injectable } from "@angular/core";
import { Storage } from '@ionic/storage-angular';
import { NotificationService } from "./notification.service";

@Injectable({
  providedIn: 'root'
})
export class StorageService<T> {
  constructor(private storage: Storage, private notificationService: NotificationService) {
    this.createDB();
  }

  async createDB() {
    const storage = await this.storage.create();
    this.storage = storage;
    }
    
  private insert(key: string, payload: T[]): Promise<any> {
    return this.storage.set(key, payload);
  } 

  getAll(key: string): Promise<T[]> {
		return this.storage.get(key);
  }

  save(key: string, payload: T[], showToast?: boolean) {
    this.insert(key, payload).then(() => {
      this.notificationService.showToast('Sucesso!', 'Operação realizada com sucesso!', 'success', showToast)
      .catch(() => {
        this.notificationService.showToast('Ocorreu um erro', 'Tente novamente mais tarde', 'danger')
      })
    })
  }

  clear(key: string) {
    this.storage.remove(key)
    console.log('Dados apagados')
  }
}

