import { Injectable } from "@angular/core";
import { AlertController, ToastController } from "@ionic/angular";

@Injectable({
    providedIn: 'root'
})
export class NotificationService {

  constructor(
    private alertCtrl: AlertController, 
    private toastCtrl: ToastController, 
  ) {}


  async showAlert(msg: string) {
    const alert = await this.alertCtrl.create({
      header: 'Alerta',
      message: msg,
      buttons: ['OK']
    });

    await alert.present();
  }

  async showToast(header: string, msg: string, color: string, showToast = true) {
    if (showToast) {
      const toast = await this.toastCtrl.create({
        header: header,
        message: msg,
        color: color,
        duration: 1500,
        position: 'top',
      });
  
      await toast.present();
    }
  }
}