import { IListItem } from "./list-item.interface";

export interface IList{
  id: number
  name: string;
  budget: number;
  items: IListItem[];
}