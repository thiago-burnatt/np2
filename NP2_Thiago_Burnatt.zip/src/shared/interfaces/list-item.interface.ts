import { IItem } from "./items.interface";

export interface IListItem {
  item: IItem;
  quantity: number;
  checked: boolean;
}