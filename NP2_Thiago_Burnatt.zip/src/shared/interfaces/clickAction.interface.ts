export interface IClickAction {
  index: number;
  action: string;
}