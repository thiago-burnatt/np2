import { ICategory } from "./categories.interface";

export interface IItem {
  id: number;
  name: string;
  category: ICategory;
  value: number;
}